"use client"

import * as React from "react"
import { motion, useAnimation, useInView } from "framer-motion"

export const LetterPullUp = ({
  text,
  className,
}: {
  text: string
  className?: string
}) => {
  const controls = useAnimation()
  const ref = React.useRef(null)
  const inView = useInView(ref, { once: true })

  React.useEffect(() => {
    if (inView) {
      controls.start("visible")
    }
  }, [controls, inView])

  const letterVariants = {
    hidden: { y: "100%" },
    visible: { y: 0 },
  }

  return (
    <div ref={ref} className={className}>
      {text.split("").map((letter, index) => (
        <motion.span
          key={index}
          variants={letterVariants}
          initial="hidden"
          animate={controls}
          transition={{
            duration: 0.5,
            ease: [0.33, 1, 0.68, 1],
            delay: index * 0.05,
          }}
          style={{ display: "inline-block", overflow: "hidden" }}
        >
          {letter === " " ? "\u00A0" : letter}
        </motion.span>
      ))}
    </div>
  )
}

