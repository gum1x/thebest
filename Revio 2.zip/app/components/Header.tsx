'use client'

import { useState, useEffect } from "react";
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import ContactButton from './ContactButton'

let tabs = [
  { id: "pricing", label: "Pricing", href: "/pricing" },
  { id: "whitepaper", label: "Whitepaper", href: "/whitepaper" },
  { id: "how-it-works", label: "How it Works", href: "/how-it-works" },
];

function AnimatedTabs() {
  const pathname = usePathname()
  let [activeTab, setActiveTab] = useState("");

  return (
    <div className="flex space-x-1">
      {tabs.map((tab) => (
        <Link
          key={tab.id}
          href={tab.href}
          onClick={() => setActiveTab(tab.id)}
          className={`
            text-white relative rounded-full px-4 py-2 text-base font-semibold transition duration-300 focus-visible:outline-2
            hover:text-green-500
          `}
          style={{
            WebkitTapHighlightColor: "transparent",
          }}
        >
          <span className="relative z-20">{tab.label}</span>
        </Link>
      ))}
    </div>
  );
}

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 shadow-md transition-colors duration-300 ${isScrolled ? 'bg-black' : 'bg-black bg-opacity-80 backdrop-blur-sm'}`}>
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="mr-6">
          <h1 className="text-2xl font-bold uppercase font-chakra-petch text-white">
            Revio
          </h1>
        </Link>
        <div className="flex-grow flex justify-center">
          <AnimatedTabs />
        </div>
        <div className="ml-6">
          <ContactButton />
        </div>
      </div>
      <div className="h-[0.5px] w-full bg-white opacity-50"></div>
    </header>
  )
}

