"use client"

import React from "react"
import { cn } from "@/lib/utils"

interface ShimmerButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  shimmerColor?: string
  shimmerSize?: string
  borderRadius?: string
  shimmerDuration?: string
  background?: string
  className?: string
  children?: React.ReactNode
}

const ShimmerButton = React.forwardRef<HTMLButtonElement, ShimmerButtonProps>(
  (
    {
      shimmerColor = "#ffffff",
      shimmerSize = "0.1em",
      borderRadius = "9999px",
      shimmerDuration = "2s",
      background = "radial-gradient(ellipse 80% 50% at 50% 120%,rgba(62, 61, 117),rgba(18, 18, 38))",
      className,
      children,
      ...props
    },
    ref
  ) => {
    return (
      <button
        ref={ref}
        className={cn(
          "group relative flex cursor-pointer items-center justify-center overflow-hidden rounded-full text-base font-bold leading-none text-white",
          className
        )}
        {...props}
      >
        <span
          className="absolute inset-0 overflow-hidden rounded-full"
          style={{ background }}
        >
          <span
            className="absolute inset-0 animate-[shimmer_2s_linear_infinite] overflow-hidden rounded-full"
            style={{
              background: `linear-gradient(90deg,transparent 0%,${shimmerColor} 50%,transparent 100%)`,
              transform: "translateX(-100%)",
              WebkitMaskImage: `radial-gradient(${shimmerSize},black,transparent)`,
              maskImage: `radial-gradient(${shimmerSize},black,transparent)`,
            }}
          ></span>
        </span>
        <span className="absolute inset-0 rounded-full border-2 border-white opacity-20"></span>
        <div className="relative z-10 flex items-center justify-center rounded-full bg-black px-6 py-3 text-base font-bold text-white transition-all duration-200 ease-out group-hover:bg-gray-900 m-[1px]">
          {children}
        </div>
      </button>
    )
  }
)

ShimmerButton.displayName = "ShimmerButton"

export { ShimmerButton }

