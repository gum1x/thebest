'use client'

import { motion } from 'framer-motion'
import { MagicCard } from './MagicCard'
import { FadeInSection } from './FadeInSection'
import { ClipboardList, Zap, ShieldCheck } from 'lucide-react'
import Link from 'next/link'

const steps = [
  {
    title: 'Info Collection',
    description: 'We start by understanding your situation. Through a call or text, we gather essential details like your username, associated email or phone number, error messages, and the nature of the ban. This information is crucial for assessing your case and planning our approach.',
    icon: ClipboardList,
  },
  {
    title: 'Direct Action',
    description: 'With the necessary information in hand, our team leverages insider connections and proven techniques to escalate your case directly to platform representatives. We guarantee successful recovery, regardless of the reason for the ban or restriction.',
    icon: Zap,
  },
  {
    title: 'Recovery',
    description: 'Once your account is successfully recovered, we ensure everything is in order. If you encounter any issues or need further assistance, our support team is always ready to help.',
    icon: ShieldCheck,
  },
]

export default function HowItWorksSection() {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 relative z-10">
          <motion.h1 
            className="text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Our Recovery Process
          </motion.h1>
          <motion.p 
            className="text-lg text-gray-400 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
          >
            Learn how we help you regain access to your accounts quickly and efficiently.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto relative z-10">
          {steps.map((step, index) => (
            <FadeInSection key={step.title}>
              <MagicCard className="h-full bg-gray-900 border border-gray-800">
                <div className="p-8">
                  <step.icon className="w-12 h-12 text-green-500 mb-6" />
                  <h3 className="text-2xl font-bold text-white mb-4">{step.title}</h3>
                  <p className="text-gray-400">{step.description}</p>
                </div>
              </MagicCard>
            </FadeInSection>
          ))}
        </div>

        <motion.div 
          className="text-center mt-16 relative z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <p className="text-gray-400 text-lg md:text-xl mb-12 max-w-2xl mx-auto">
            Ready to get your account back? <Link href="https://calendly.com/d/cqmk-fm4-jch" className="text-green-500 hover:underline">Contact</Link> our recovery specialists today.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

