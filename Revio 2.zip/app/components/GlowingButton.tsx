'use client'

import React from 'react'
import { motion } from 'framer-motion'

interface GlowingButtonProps {
  children: React.ReactNode
  onClick?: () => void
  href?: string
}

export const GlowingButton: React.FC<GlowingButtonProps> = ({ children, onClick, href }) => {
  const buttonContent = (
    <motion.button
      className="relative px-6 py-3 bg-green-500 text-white text-sm font-bold rounded-full overflow-hidden group"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
    >
      <span className="relative z-10">{children}</span>
      <motion.div
        className="absolute inset-0 bg-green-400"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
      />
      <motion.div
        className="absolute -inset-1.5 bg-gradient-to-r from-green-400 to-green-600 rounded-full opacity-30 blur-lg group-hover:opacity-50 transition duration-300"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.3 }}
        transition={{ duration: 0.3 }}
      />
    </motion.button>
  )

  return href ? (
    <a href={href} target="_blank" rel="noopener noreferrer">
      {buttonContent}
    </a>
  ) : (
    buttonContent
  )
}

