import { Organization, WithContext } from 'schema-dts'

export const StructuredData = () => {
  const orgData: WithContext<Organization> = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Revio',
    url: 'https://www.revio.cc',
    logo: 'https://www.revio.cc/logo.png',
    sameAs: [
      'https://www.facebook.com/RevioTeam',
      'https://www.twitter.com/RevioTeam',
      'https://www.linkedin.com/company/revio',
      'https://www.instagram.com/revioteam'
    ],
    description: 'Revio specializes in recovering banned or restricted social media accounts for Instagram and TikTok.',
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(orgData) }}
    />
  )
}

