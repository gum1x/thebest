'use client'

import { motion } from 'framer-motion'
import { MagicCard } from './MagicCard'
import { Check, Clock } from 'lucide-react'
import Link from 'next/link'

const pricingData = [
  {
    title: 'Instagram Recovery',
    price: '300',
    timeframe: 'Instant - 48 hours',
    features: [
      'Dedicated support team',
      'Priority handling',
      'Post-recovery security audit'
    ]
  },
  {
    title: 'TikTok Recovery',
    price: '2,500',
    timeframe: 'Instant - 48 hours',
    features: [
      'Full account restoration',
      '24/7 expert assistance',
      'Expedited process',
      'Content recovery support'
    ]
  },
  {
    title: 'Account Shielding',
    price: '3,000',
    timeframe: 'Instant - 48 hours',
    features: [
      'Proactive account protection',
      'Regular security checks',
      'Instant alert system',
      'Personalized security consultation'
    ]
  },
  {
    title: 'Instagram Username Claims',
    price: 'TBA',
    timeframe: 'Coming Soon',
    features: [
      'Secure desired usernames',
      'Expert negotiation',
      'Legal compliance assurance',
      'Seamless username transfer'
    ],
    comingSoon: true
  }
]

export default function PricingSection() {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 relative z-10">
          <motion.h1 
            className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Simple, Transparent Pricing
          </motion.h1>
          <motion.p 
            className="text-lg text-gray-400 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
          >
            Choose the service you need. Pay only when your account is successfully recovered or protected.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto relative z-10">
          {pricingData.map((plan, index) => (
            <motion.div
              key={plan.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <MagicCard className="h-full bg-gray-900 border border-gray-800">
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-white mb-4">{plan.title}</h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-white">
                      {plan.price === 'TBA' ? 'TBA' : `$${plan.price}`}
                    </span>
                  </div>
                  <p className="text-lg text-gray-400 mb-6">{plan.timeframe}</p>
                  <ul className="mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center mb-2">
                        <Check className="w-5 h-5 mr-2 text-green-500" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  {plan.comingSoon ? (
                    <div className="w-full bg-gray-700 text-white font-bold py-2 px-4 rounded opacity-50 flex items-center justify-center">
                      <Clock className="w-5 h-5 mr-2" />
                      Coming Soon
                    </div>
                  ) : (
                    <Link href="https://calendly.com/d/cqmk-fm4-jch" passHref>
                      <button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded transition duration-300">
                        Get Started
                      </button>
                    </Link>
                  )}
                </div>
              </MagicCard>
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="text-center mt-16 relative z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <p className="text-gray-400 text-sm">
            All services include our no-recovery, no-payment guarantee. 
            <br />
            Contact us for custom solutions or special cases.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

