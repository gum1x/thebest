import Image from 'next/image'

interface Review {
  username: string
  followCount: number
  rating: number
  comment: string
}

const reviews: Review[] = [
  { username: "unbanned_gamer", followCount: 1243, rating: 5, comment: "Revio got my account back in just 3 days! Absolutely amazing service!" },
  { username: "streamer_123", followCount: 15678, rating: 4, comment: "Was skeptical at first, but they really came through. Highly recommend!" },
  { username: "social_butterfly", followCount: 8901, rating: 3, comment: "It took longer than expected, but I got my account back eventually." },
  { username: "tech_guru", followCount: 32456, rating: 5, comment: "Professional service, quick resolution. Worth every penny!" },
  { username: "gaming_legend", followCount: 67890, rating: 2, comment: "Didn't work for me initially, but their support was helpful." },
  { username: "influencer_pro", followCount: 123456, rating: 5, comment: "Saved my career! Can't thank Revio enough for their incredible service." },
]

export function UserReviews() {
  return (
    <section className="py-12 relative overflow-hidden w-full">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">What Our Users Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <div key={index} className="bg-gray-800 rounded-lg p-6 shadow-lg">
              <div className="flex items-center mb-4">
                <Image
                  src={`/placeholder.svg?height=50&width=50&text=${review.username[0].toUpperCase()}`}
                  alt={review.username}
                  width={50}
                  height={50}
                  className="rounded-full mr-4"
                />
                <div>
                  <h3 className="font-bold">{review.username}</h3>
                  <p className="text-sm text-gray-400">{review.followCount.toLocaleString()} followers</p>
                </div>
              </div>
              <div className="flex items-center mb-2">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className={`w-5 h-5 ${i < review.rating ? 'text-yellow-400' : 'text-gray-600'}`}
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-300">{review.comment}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

