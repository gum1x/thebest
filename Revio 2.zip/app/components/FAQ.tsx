'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Minus } from 'lucide-react'

const faqs = [
  {
    question: "How long does the account recovery process usually take?",
    answer: "The recovery process typically takes between 24 to 48 hours, depending on the complexity of the case and the platform involved. We work diligently to restore your account as quickly as possible."
  },
  {
    question: "What if my account can't be recovered?",
    answer: "We have a high success rate, but in the rare event that we can't recover your account, you won't be charged. Our service is based on a no-recovery, no-payment guarantee."
  },
  {
    question: "Is my information safe with Revio?",
    answer: "Absolutely. We take data privacy and security very seriously. All information you provide is encrypted and used solely for the purpose of recovering your account."
  },
  {
    question: "Can you help with accounts on platforms other than Instagram and TikTok?",
    answer: "While we specialize in Instagram and TikTok, we may be able to assist with other platforms as well. Please contact us for more information about your specific case."
  }
]

export function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold text-white mb-8 text-center">Frequently Asked Questions</h2>
      {faqs.map((faq, index) => (
        <div key={index} className="mb-4">
          <button
            className="flex justify-between items-center w-full text-left p-4 bg-gray-800 rounded-lg focus:outline-none"
            onClick={() => setActiveIndex(activeIndex === index ? null : index)}
          >
            <span className="text-lg font-medium text-white">{faq.question}</span>
            {activeIndex === index ? (
              <Minus className="w-5 h-5 text-gray-400" />
            ) : (
              <Plus className="w-5 h-5 text-gray-400" />
            )}
          </button>
          <AnimatePresence>
            {activeIndex === index && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <p className="p-4 text-gray-400">{faq.answer}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  )
}

