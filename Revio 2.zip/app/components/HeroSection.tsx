"use client";

import { GridPattern } from "./GridPattern";
import { RainbowButton } from "./RainbowButton";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import Link from "next/link";

export function HeroSection() {
	const scrollToReviews = () => {
		const reviewsSection = document.getElementById("reviews-section");
		if (reviewsSection) {
			const scrollTarget =
				reviewsSection.offsetTop + reviewsSection.offsetHeight / 128;
			window.scrollTo({
				top: scrollTarget,
				behavior: "smooth",
			});
		}
	};

	return (
		<section className="relative min-h-[120vh]">
			<GridPattern width={10} height={10} className="absolute inset-0 z-0" />
			<div className="relative z-10 bg-black bg-opacity-50 min-h-[120vh] flex flex-col items-center">
				<div className="w-full mt-24">
					<div className="pt-36 pb-96 container mx-auto px-4">
						<h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-rubik font-black max-w-4xl mx-auto leading-tight text-center px-4 mb-8 text-white [color-scheme:dark] py-2">
							<span className="grey-white-gradient-text block">
								We'll get your account back,
							</span>
							<span className="grey-white-gradient-text block mt-2">
								only pay once it's <span className="font-black">restored</span>
							</span>
							<p className="text-sm text-gray-400 font-normal max-w-3xl mx-auto mt-4 px-4">
								We specialize in legally unbanning social media accounts,
								helping you reclaim your online presence
							</p>
						</h2>
						<div className="flex flex-col items-center space-y-8 mt-5">
							<motion.div
								initial={{ opacity: 0, y: 20 }}
								animate={{ opacity: 1, y: 0 }}
								transition={{ duration: 0.5 }}
							>
								<Link
									href="https://calendly.com/d/cqmk-fm4-jch"
									target="_blank"
									rel="noopener noreferrer"
								>
									<RainbowButton>Start Your Account Recovery Now</RainbowButton>
								</Link>
							</motion.div>
							<motion.div
								initial={{ opacity: 0, y: 20 }}
								animate={{ opacity: 1, y: 0 }}
								transition={{ duration: 0.5, delay: 0.2 }}
							>
								<Link href="/how-it-works">
									<RainbowButton>Learn about our process</RainbowButton>
								</Link>
							</motion.div>
						</div>
					</div>
				</div>

				{/* Scroll Down Button */}
				<div className="absolute bottom-24 left-0 right-0 flex justify-center items-center h-32">
					<motion.button
						onClick={scrollToReviews}
						className="size-12 rounded-full bg-gray-800/80 backdrop-blur-sm flex items-center justify-center cursor-pointer border border-gray-700/30 hover:bg-gray-700/90 transition-colors"
						animate={{
							y: [0, -10, 0],
						}}
						transition={{
							duration: 1.5,
							times: [0, 0.4, 1],
							repeat: Number.POSITIVE_INFINITY,
							ease: [0.33, 1, 0.68, 1],
						}}
						whileHover={{ scale: 1.1 }}
						whileTap={{ scale: 0.9 }}
					>
						<ChevronDown className="text-gray-400 w-6 h-6" />
					</motion.button>
				</div>
			</div>
		</section>
	);
}
