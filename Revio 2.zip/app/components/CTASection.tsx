"use client";

import { motion } from "framer-motion";
import { FadeInSection } from "./FadeInSection";
import { LetterPullUp } from "../../components/ui/letter-pullup";
import { GlowingButton } from "./GlowingButton";

export function CTASection() {
	return (
		<section className="py-32 relative overflow-hidden bg-black">
			<div className="container mx-auto px-4 relative">
				<FadeInSection>
					<div className="max-w-4xl mx-auto text-center relative z-10">
						<h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight text-white">
							Regain access to your accounts
							<LetterPullUp
								text="SUPER FAST"
								className="block mt-2 text-green-500"
							/>
						</h2>

						<p className="text-gray-400 text-lg md:text-xl mb-12 max-w-2xl mx-auto">
							Most accounts are recovered within 24 hours. Don't let a ban ruin
							your online presence.
						</p>

						<motion.div
							initial={{ opacity: 0, y: 20 }}
							animate={{ opacity: 1, y: 0 }}
							transition={{ delay: 0.2 }}
							className="flex justify-center"
						>
							<GlowingButton href="https://calendly.com/d/cqmk-fm4-jch">
								Contact Our Recovery Specialists
							</GlowingButton>
						</motion.div>
					</div>
				</FadeInSection>
			</div>
		</section>
	);
}
