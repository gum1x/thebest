'use client'

import { motion, useAnimation, useInView } from 'framer-motion'
import { Star } from 'lucide-react'
import { useEffect, useMemo, useRef } from 'react'
import { MagicCard } from './MagicCard'

interface Review {
  id: string;
  rating: number;
  title: string;
  content: string;
  author: string;
  date: string;
  verified: boolean;
}

const reviews: Review[] = [
  {
    id: "1",
    rating: 5,
    title: "Highly Recommended",
    content: "Impressed by how quickly Revio resolved my issue. Definitely worth the investment for peace of mind.",
    author: "Ryan Jackson",
    date: "13 days ago",
    verified: true
  },
  {
    id: "2",
    rating: 5,
    title: "Exceptional Customer Care",
    content: "Saw Revio mentioned in an article and decided to give them a try. Best decision ever! They restored my account in no time.",
    author: "Emily Anderson",
    date: "22 days ago",
    verified: true
  },
  {
    id: "3",
    rating: 4.8,
    title: "Account Recovered Quickly",
    content: "Revio helped me recover my account quickly and efficiently. Their team was professional and kept me updated throughout the process. I'm extremely grateful for their service!",
    author: "James Smith",
    date: "5 days ago",
    verified: true
  },
  {
    id: "4",
    rating: 4.9,
    title: "Excellent Support Team",
    content: "Thanks Revio! You guys really came through when I needed help the most. My account is back and running smoothly now.",
    author: "Emma Johnson",
    date: "18 days ago",
    verified: false
  },
  {
    id: "5",
    rating: 4.7,
    title: "Saved My Business Account",
    content: "After trying everything to recover my account, Revio was the only service that actually delivered results.",
    author: "Liam Williams",
    date: "2 days ago",
    verified: true
  },
  {
    id: "6",
    rating: 5,
    title: "Fast and Efficient Service",
    content: "I was skeptical at first, but Revio proved me wrong. Their expertise in account recovery is unmatched.",
    author: "Olivia Brown",
    date: "10 days ago",
    verified: true
  },
  {
    id: "7",
    rating: 4.9,
    title: "Professional and Reliable",
    content: "Revio's support team went above and beyond to help me. They were patient, knowledgeable, and incredibly effective.",
    author: "Noah Jones",
    date: "25 days ago",
    verified: false
  },
  {
    id: "8",
    rating: 4.8,
    title: "Highly Recommended",
    content: "I can't thank Revio enough for their help. They made a stressful situation so much easier to handle.",
    author: "Ava Garcia",
    date: "15 days ago",
    verified: true
  },
  {
    id: "9",
    rating: 5,
    title: "Great Communication",
    content: "Lost hope of ever recovering my account until I found Revio. They worked tirelessly to get it back for me.",
    author: "Ethan Miller",
    date: "8 days ago",
    verified: true
  },
  {
    id: "10",
    rating: 4.7,
    title: "Worth Every Penny",
    content: "Impressed by how quickly Revio resolved my issue. Definitely worth the investment for peace of mind.",
    author: "Sophia Davis",
    date: "29 days ago",
    verified: false
  }
];

const totalReviews = 382; // Updated to 382 reviews

const StarRating = ({ rating }: { rating: number }) => {
  return (
    <div className="flex gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < Math.floor(rating) ? 'fill-green-500 text-green-500' : 
            (i === Math.floor(rating) && rating % 1 > 0) ? 'fill-green-500 text-green-500' : 'fill-gray-300 text-gray-300'
          }`}
        />
      ))}
    </div>
  )
}

export function TrustpilotStyle() {
  const controls = useAnimation()
  const titleRef = useRef(null)
  const isInView = useInView(titleRef, { once: true, amount: 0.5 })

  const averageRating = useMemo(() => {
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0)
    return (sum / reviews.length).toFixed(1)
  }, [])

  useEffect(() => {
    controls.start({
      x: [0, -100 * reviews.length],
      transition: {
        x: {
          repeat: Infinity,
          repeatType: "loop",
          duration: reviews.length * 10,
          ease: "linear",
        },
      },
    })
  }, [controls])

  const titleVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
  }

  return (
    <section id="reviews-section" className="py-20 relative overflow-hidden bg-gradient-to-b from-[#0A0A0B] to-black">
      <div className="container mx-auto px-4 pb-12">
        <motion.div
          ref={titleRef}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          variants={titleVariants}
          className="text-center mb-12"
        >
          <h3 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            Review's From Our Happy Clients
          </h3>
          <div className="flex justify-center items-center gap-2 mb-4">
            <StarRating rating={parseFloat(averageRating)} />
            <span className="text-lg font-semibold ml-2 text-white">{averageRating} out of 5</span>
          </div>
          <p className="text-gray-400">
            Based on <span className="font-semibold">{totalReviews} reviews</span> on <span className="text-green-500 font-semibold">Trustpilot</span>
          </p>
        </motion.div>

        <div className="relative">
          <motion.div
            className="flex gap-4"
            animate={controls}
            style={{ width: `${reviews.length * 320}px` }}
          >
            {reviews.map((review) => (
              <motion.div
                key={review.id}
                className="w-[300px] flex-shrink-0"
                whileHover={{ scale: 1.02 }}
              >
                <MagicCard className="h-full p-4 bg-gradient-to-br from-gray-900 to-black">
                  <div className="flex flex-col h-full">
                    <div className="flex items-start justify-between mb-2">
                      <StarRating rating={review.rating} />
                      {review.verified && (
                        <span className="text-xs px-2 py-1 bg-green-500/10 text-green-500 rounded-full">
                          Verified
                        </span>
                      )}
                    </div>
                    
                    <h3 className="text-sm font-semibold mb-2 line-clamp-1 text-white">{review.title}</h3>
                    
                    <p className="text-xs text-gray-300 flex-grow mb-2 line-clamp-3">{review.content}</p>
                    
                    <div className="mt-auto text-xs">
                      <div className="font-medium text-gray-200">{review.author}</div>
                      <div className="text-gray-400">{review.date}</div>
                    </div>
                  </div>
                </MagicCard>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}

