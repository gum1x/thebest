"use client";

import type React from "react";
import { useState } from "react";
import { type Colors, Liquid } from "../../app/components/core/liquid-gradient";

const COLORS: Colors = {
	color1: "#FFFFFF",
	color2: "#10C510",
	color3: "#89E289",
	color4: "#FCFEFC",
	color5: "#F9FDF9",
	color6: "#B2E7B2",
	color7: "#0ECB0E",
	color8: "#00E900",
	color9: "#43EF43",
	color10: "#7BF47B",
	color11: "#06FC06",
	color12: "#C1EAC1",
	color13: "#03DE03",
	color14: "#BAF6BA",
	color15: "#BEE7BE",
	color16: "#0ECB0E",
	color17: "#4CC04C",
};

const ContactButton: React.FC = () => {
	const [isHovered, setIsHovered] = useState(false);

	return (
		<div className="flex justify-center">
			<a
				href="https://calendly.com/d/cqmk-fm4-jch"
				target="_blank"
				rel="noopener noreferrer"
				className="relative inline-block sm:w-36 w-14 h-[2.7em] mx-auto group dark:bg-black bg-white dark:border-white border-black border-2 rounded-lg"
			>
				<div className="absolute w-[112.81%] h-[128.57%] top-[8.57%] left-1/2 -translate-x-1/2 filter blur-[19px] opacity-70">
					<span className="absolute inset-0 rounded-lg bg-[#d9d9d9] filter blur-[6.5px]"></span>
					<div className="relative w-full h-full overflow-hidden rounded-lg">
						<Liquid isHovered={isHovered} colors={COLORS} />
					</div>
				</div>
				<div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[40%] w-[92.23%] h-[112.85%] rounded-lg bg-[#010128] filter blur-[7.3px]"></div>
				<div className="relative w-full h-full overflow-hidden rounded-lg">
					<span className="absolute inset-0 rounded-lg bg-[#d9d9d9]"></span>
					<span className="absolute inset-0 rounded-lg bg-green-900"></span>
					<Liquid isHovered={isHovered} colors={COLORS} />
					{[1, 2, 3, 4, 5].map((i) => (
						<span
							key={i}
							className={`absolute inset-0 rounded-lg border-solid border-[3px] border-gradient-to-b from-transparent to-white mix-blend-overlay filter ${
								i <= 2 ? "blur-[3px]" : i === 3 ? "blur-[5px]" : "blur-[4px]"
							}`}
						></span>
					))}
					<span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[40%] w-[70.8%] h-[42.85%] rounded-lg filter blur-[15px] bg-[#006]"></span>
				</div>
				<button
					className="absolute inset-0 rounded-lg bg-transparent cursor-pointer"
					aria-label="Contact Us"
					type="button"
					onMouseEnter={() => setIsHovered(true)}
					onMouseLeave={() => setIsHovered(false)}
				>
					<span className="flex items-center justify-center px-4 rounded-lg group-hover:text-green-300 text-white text-sm sm:text-base font-semibold tracking-wide whitespace-nowrap">
						<span>Contact Us</span>
					</span>
				</button>
			</a>
		</div>
	);
};

export default ContactButton;
