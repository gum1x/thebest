'use client'

import { Check, X } from 'lucide-react'

const features = [
  { name: 'Account Recovery', instagram: true, tiktok: true, shielding: true },
  { name: 'Dedicated Support Team', instagram: true, tiktok: true, shielding: true },
  { name: 'Priority Handling', instagram: true, tiktok: true, shielding: true },
  { name: 'Content Recovery', instagram: false, tiktok: true, shielding: false },
  { name: '24/7 Expert Assistance', instagram: false, tiktok: true, shielding: true },
  { name: 'Proactive Protection', instagram: false, tiktok: false, shielding: true },
  { name: 'Regular Security Checks', instagram: false, tiktok: false, shielding: true },
  { name: 'Instant Alert System', instagram: false, tiktok: false, shielding: true },
]

export function ComparisonTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="border-b border-gray-700">
            <th className="py-4 px-6 text-sm font-medium text-gray-400">Feature</th>
            <th className="py-4 px-6 text-sm font-medium text-gray-400">Instagram Recovery</th>
            <th className="py-4 px-6 text-sm font-medium text-gray-400">TikTok Recovery</th>
            <th className="py-4 px-6 text-sm font-medium text-gray-400">Account Shielding</th>
          </tr>
        </thead>
        <tbody>
          {features.map((feature, index) => (
            <tr key={index} className="border-b border-gray-800">
              <td className="py-4 px-6 text-sm text-gray-300">{feature.name}</td>
              <td className="py-4 px-6">{feature.instagram ? <Check className="text-green-500" /> : <X className="text-red-500" />}</td>
              <td className="py-4 px-6">{feature.tiktok ? <Check className="text-green-500" /> : <X className="text-red-500" />}</td>
              <td className="py-4 px-6">{feature.shielding ? <Check className="text-green-500" /> : <X className="text-red-500" />}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

