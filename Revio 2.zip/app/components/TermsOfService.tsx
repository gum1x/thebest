import { motion } from 'framer-motion'

const sections = [
  {
    title: "1. Service Scope",
    content: [
      "1.1. Revio provides professional assistance with account recovery and unban services for supported online platforms, leveraging our expertise and tailored strategies.",
      "1.2. While we strive for success in every case, we do not guarantee specific outcomes. The result of our services depends on factors such as platform policies, account history, and other circumstances beyond our control.",
      "1.3. Our services are strictly limited to recovery and unban assistance. We are not responsible for any subsequent actions taken by the platform."
    ]
  },
  {
    title: "2. Eligibility",
    content: [
      "2.1. You must be at least 18 years old or the age of majority in your jurisdiction to use our services.",
      "2.2. By using our services, you affirm that you are the rightful owner of the account in question or have explicit authorization to act on behalf of the owner.",
      "2.3. You agree to comply with all applicable laws and regulations when using our services."
    ]
  },
  {
    title: "3. User Responsibilities",
    content: [
      "3.1. You are responsible for providing accurate, complete, and truthful information necessary for us to process your request effectively.",
      "3.2. You must promptly respond to any requests for additional information or clarification.",
      "3.3. You will not use our services for unlawful purposes, including unauthorized access to accounts or any activities that violate platform terms.",
      "3.4. You acknowledge that providing false or misleading information may result in delays, unsuccessful outcomes, or termination of service."
    ]
  },
  {
    title: "4. Fees and Payments",
    content: [
      "4.1. All service fees are clearly outlined on our website and are subject to periodic updates. Any changes will not affect services already purchased.",
      "4.2. Payment must be made in full at the time of placing a request. Payment methods are specified during the checkout process.",
      "4.3. Service fees are generally non-refundable unless explicitly stated otherwise in Section 5.",
      "4.4. Any additional costs incurred due to inaccurate information or unforeseen complications will be communicated and may be subject to additional charges."
    ]
  },
  {
    title: "5. Refund Policy",
    content: [
      "5.1. Refunds are issued only under the following conditions:",
      "- No attempt was made to process your unban request within the agreed timeframe.",
      "- You request a cancellation before any actions are initiated.",
      "5.2. Refunds are not granted if:",
      "- The platform denies the unban request despite our reasonable efforts.",
      "- Inaccurate or incomplete information was provided by you.",
      "- The account is found to violate platform policies irreparably.",
      "5.3. All refund requests must be submitted within 14 days of service completion or cancellation."
    ]
  },
  {
    title: "6. Confidentiality and Privacy",
    content: [
      "6.1. We prioritize your privacy and adhere to strict data protection protocols as outlined in our Privacy Policy.",
      "6.2. Information you provide will be used exclusively for the unban process and securely stored. Upon case resolution, all sensitive data will be permanently deleted.",
      "6.3. We will not share your information with third parties without your explicit consent, except as required by law."
    ]
  },
  {
    title: "7. Limitation of Liability",
    content: [
      "7.1. Revio is an independent service provider and is not affiliated with or endorsed by any social media platforms or companies.",
      "7.2. We are not liable for any adverse actions taken by the platform, including permanent bans, account restrictions, or policy changes.",
      "7.3. Our total liability for any claims arising from our services is strictly limited to the amount paid by you for the service in question."
    ]
  },
  {
    title: "8. Indemnification",
    content: [
      "You agree to indemnify, defend, and hold harmless Revio, its officers, employees, and agents from any claims, damages, losses, or liabilities arising out of:",
      "- Your breach of these Terms of Service.",
      "- Your misuse of our services.",
      "- Any false or unauthorized information provided by you."
    ]
  },
  {
    title: "9. Termination",
    content: [
      "9.1. We reserve the right to terminate or refuse services at our discretion if you:",
      "- Violate these Terms of Service.",
      "- Engage in fraudulent, abusive, or unethical conduct.",
      "9.2. Termination of services does not entitle you to a refund unless explicitly outlined in Section 5."
    ]
  },
  {
    title: "10. Dispute Resolution",
    content: [
      "10.1. Any disputes arising out of these Terms of Service shall be resolved through binding arbitration in accordance with the laws of [Your Jurisdiction].",
      "10.2. By using our services, you waive the right to participate in class-action lawsuits or other collective legal actions against Revio.",
      "10.3. Arbitration fees and costs shall be borne as determined by the arbitrator."
    ]
  },
  {
    title: "11. Amendments",
    content: [
      "11.1. Revio reserves the right to modify these Terms of Service at any time. Such changes will take effect immediately upon being posted on our website.",
      "11.2. Continued use of our services after updates constitutes acceptance of the revised Terms of Service."
    ]
  },
  {
    title: "12. Contact Us",
    content: [
      "For inquiries, assistance, or disputes regarding these Terms of Service, please contact us via email at contact@revio.cc or through our website support portal."
    ]
  }
]

export default function TermsOfService() {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.h1 
          className="text-4xl md:text-5xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-400"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Terms of Service
        </motion.h1>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-3xl mx-auto bg-gray-900 rounded-lg p-8 shadow-lg"
        >
          <p className="text-gray-300 mb-8">
            Welcome to Revio! By using our unban services, you agree to be bound by these Terms of Service ("ToS"). Please read them carefully.
          </p>
          {sections.map((section, index) => (
            <div key={index} className="mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">{section.title}</h2>
              {section.content.map((paragraph, pIndex) => (
                <p key={pIndex} className="text-gray-300 mb-2">{paragraph}</p>
              ))}
            </div>
          ))}
          <p className="text-gray-300 mt-8">
            By using Revio services, you acknowledge that you have read, understood, and agreed to these Terms of Service.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

