"use client";

import { useId } from "react";
import { cn } from "../../lib/utils";

interface GridPatternProps {
	width?: number;
	height?: number;
	x?: number;
	y?: number;
	squares?: Array<[x: number, y: number]>;
	strokeDasharray?: string;
	className?: string;
	[key: string]: unknown;
}

export function GridPattern({
	width = 4, // Reduced from 5 to 4
	height = 4, // Reduced from 5 to 4
	x = -1,
	y = -1,
	strokeDasharray = "0",
	squares = Array.from({ length: 25 }, (_, i) => [
		Math.floor(Math.random() * 6),
		Math.floor(Math.random() * 6),
	]),
	className,
	...props
}: GridPatternProps) {
	const id = useId();

	return (
		<svg
			aria-hidden="true"
			className={cn(
				"pointer-events-none absolute inset-0 h-full w-full fill-gray-400/30 stroke-gray-400/30",
				"[mask-image:radial-gradient(ellipse_at_center,black_50%,transparent_90%)]",
				className,
			)}
			{...props}
		>
			<defs>
				<pattern
					id={id}
					width={width}
					height={height}
					patternUnits="userSpaceOnUse"
					x={x}
					y={y}
				>
					<path
						d={`M.5 ${height}V.5H${width}`}
						fill="none"
						strokeDasharray={strokeDasharray}
					/>
				</pattern>
			</defs>
			<rect width="100%" height="100%" strokeWidth={0} fill={`url(#${id})`} />
			{squares && (
				<svg x={x} y={y} className="overflow-visible">
					{squares.map(([squareX, squareY], index) => (
						<rect
							strokeWidth="0"
							key={`${index}-${squareX}-${squareY}`}
							width={width - 1}
							height={height - 1}
							x={squareX * width + 1}
							y={squareY * height + 1}
						/>
					))}
				</svg>
			)}
		</svg>
	);
}
