import { Metadata } from 'next'
import PricingSection from '../components/PricingSection'
import { FAQ } from '../components/FAQ'
import { GlowingButton } from '../components/GlowingButton'

export const metadata: Metadata = {
  title: 'Pricing | Revio Account Recovery Services',
  description: 'View our transparent pricing for Instagram and TikTok account recovery services. Choose the perfect plan for your needs.',
}

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0B]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#ffffff10_0%,transparent_65%)] opacity-30" />
      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at center, rgba(255,255,255,0.03) 0.5px, transparent 0.5px)',
        backgroundSize: '24px 24px'
      }} />
      <PricingSection />
      <section className="py-20 relative overflow-hidden bg-gray-900">
        <div className="container mx-auto px-4">
          <FAQ />
        </div>
      </section>
      <div className="flex justify-center mt-12 mb-16">
        <GlowingButton href="https://calendly.com/d/cqmk-fm4-jch">
          Contact Our Recovery Specialists
        </GlowingButton>
      </div>
    </div>
  )
}

