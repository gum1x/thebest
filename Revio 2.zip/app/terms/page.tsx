import { Metadata } from 'next'
import TermsOfService from '../components/TermsOfService'

export const metadata: Metadata = {
  title: 'Terms of Service | Revio Account Recovery',
  description: 'Read our Terms of Service to understand the agreement between you and Revio when using our account recovery services.',
}

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0B]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#ffffff10_0%,transparent_65%)] opacity-30" />
      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at center, rgba(255,255,255,0.03) 0.5px, transparent 0.5px)',
        backgroundSize: '24px 24px'
      }} />
      <TermsOfService />
    </div>
  )
}

