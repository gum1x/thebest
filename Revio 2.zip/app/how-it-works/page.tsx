import { Metadata } from 'next'
import HowItWorksSection from '../components/HowItWorksSection'

export const metadata: Metadata = {
  title: 'How It Works | Revio Account Recovery Process',
  description: 'Learn about our step-by-step process for recovering banned or restricted social media accounts. Discover how Revio can help you regain access.',
}

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0B]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#ffffff10_0%,transparent_65%)] opacity-30" />
      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at center, rgba(255,255,255,0.03) 0.5px, transparent 0.5px)',
        backgroundSize: '24px 24px'
      }} />
      <HowItWorksSection />
    </div>
  )
}

