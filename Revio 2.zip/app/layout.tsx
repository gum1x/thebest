import { Inter, Rubik, Chakra_Petch } from "next/font/google";
import "./globals.css";
import Header from "./components/Header";
import { Footer } from "./components/Footer";
import { ThemeProvider } from "next-themes";
import { StructuredData } from "./components/StructuredData";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const rubik = Rubik({
	subsets: ["latin"],
	weight: ["700", "900"],
	variable: "--font-rubik",
});
const chakraPetch = Chakra_Petch({
	subsets: ["latin"],
	weight: ["700"],
	variable: "--font-chakra-petch",
});

export const metadata = {
	title: "Revio",
	description: "Social media services panel",
};

export default function RootLayout({
	children,
}: {
	children: React.ReactNode;
}) {
	return (
		<html
			lang="en"
			className={`dark ${inter.variable} ${rubik.variable} ${chakraPetch.variable}`}
		>
			<body className="bg-black text-white">
				<ThemeProvider attribute="class" defaultTheme="dark">
					<div className="min-h-screen relative overflow-hidden flex flex-col">
						<Header />
						<main className="flex-grow">{children}</main>
						<Footer />
					</div>
				</ThemeProvider>
				<StructuredData />
			</body>
		</html>
	);
}
