import type { Metadata } from "next";
import { HeroSection } from "./components/HeroSection";
import { TrustpilotStyle } from "./components/TrustpilotStyle";
import { CTASection } from "./components/CTASection";

export const metadata: Metadata = {
	title: "Revio | Expert Social Media Account Recovery",
	description:
		"Revio specializes in recovering banned or restricted Instagram and TikTok accounts. Get your account back with our expert team.",
};

export default function Home() {
	return (
		<div className="relative">
			<HeroSection />

			<div className="h-[0.5px] w-full bg-white opacity-50" />

			<section className="bg-gray-900">
				<TrustpilotStyle />
			</section>

			<div className="h-[0.5px] w-full bg-white opacity-50" />

			<CTASection />
		</div>
	);
}
