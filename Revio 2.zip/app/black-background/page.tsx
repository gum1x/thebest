import React from 'react'

export default function BlackBackgroundPage() {
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white">
      <h1 className="text-4xl font-bold mb-4">Black Background Page</h1>
      <p className="text-xl">This page has a sleek, black background.</p>
    </div>
  )
}

